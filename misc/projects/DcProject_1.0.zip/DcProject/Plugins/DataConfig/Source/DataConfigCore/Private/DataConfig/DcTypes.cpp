#include "DataConfig/DcTypes.h"

DEFINE_LOG_CATEGORY(LogDataConfigCore);

