# DataConfig Sample Project

Open this with 

- UE 4.25
- UE 4.26

And check out DataConfig. For more info visit: <https://slowburn.dev/dataconfig>
